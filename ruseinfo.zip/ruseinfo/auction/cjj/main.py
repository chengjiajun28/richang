import random

from DrissionPage._configs.chromium_options import ChromiumOptions
from DrissionPage._pages.chromium_page import ChromiumPage


def init_page(self):
    do1 = ChromiumOptions().set_paths(local_port=random.randint(1000, 9999))
    page = ChromiumPage(addr_driver_opts=do1)

    return page


def get_page_obj(url):
    page = ChromiumPage()
    page.get(url=url)

    return page


if __name__ == '__main__':
    url = 'http://www.baidu.com/'
    page = get_page_obj(url)
