import random

from DrissionPage._configs.chromium_options import ChromiumOptions
from DrissionPage._pages.chromium_page import ChromiumPage


def init_page():
    do1 = ChromiumOptions().set_paths(local_port=random.randint(1000, 9999))
    page = ChromiumPage(addr_or_opts=do1)

    return page


def get_page_obj(url):
    # 创建浏览器对象
    page1 = init_page()

    page1.get(url=url, interval=3)  # 获取网页

    return page1


if __name__ == '__main__':
    url = 'http://www.baidu.com'

    for i in range(10):
        page = get_page_obj(url=url)

        page.quit()

        time.sleep()

