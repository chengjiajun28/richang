from datetime import datetime

import pymysql


def a():
    connection = pymysql.connect(
        host='118.195.246.81',
        port=3406,
        user='root',
        password='ruse#@!2022r',
        database='ruseinfo_uat',
    )

    cursor = connection.cursor()

    # 执行查询语句
    sql = f"SELECT * FROM auction_info;"
    cursor.execute(sql)
    result = cursor.fetchall()

    cursor.close()
    connection.close()

    return result


if __name__ == '__main__':
    data = a()

    from datetime import datetime

    date_string = "2023-12-28 09:49:08"
    date_format = "%Y-%m-%d %H:%M:%S"

    # 使用 strptime() 方法将字符串转换为 datetime 对象
    datetime_object = datetime.strptime(date_string, date_format)

    # 将 datetime 对象转换为新的 datetime 对象，忽略小时、分钟和秒
    truncated_datetime_object = datetime_object.replace(hour=0, minute=0, second=0)

    print(truncated_datetime_object)
    # # 使用列表推导式和三元表达式简化代码
    # if [0 if i[1] == datetime_object else 1 for i in data ]:
    #     print(1)

    # 输出结果
    # print(result)
