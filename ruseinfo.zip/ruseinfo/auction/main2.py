a = ["hahah", 'qweqerqerqwr', 'rqwerwqr']

if 1 in [11 if "a" in i and "h" in i else 0 for i in a]:
    print(1)

# 输出结果
# print(result)
